<!DOCTYPE html>
<html>
<head>
  <title>18+ Warning</title>
  <style>
    body {
      background-color: black;
      color: red;
      font-family: Impact, Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      text-align: center;
    }
    p {
      font-size: 50px;
      -webkit-text-stroke: 1px white;
    }
  </style>
</head>
<body>
  <p>This video is not allowed for kids because it contains 18+ content</p>
</body>
</html>